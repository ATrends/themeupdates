<!-- Start SearchForm -->
<form method="get" class="searchform" role="search" action="<?php echo home_url(); ?>/">
    <fieldset>
    	<input name="s" type="text" id="s" placeholder="<?php _e( 'Search', 'thevoux' ); ?>" class="small-12">
    </fieldset>
</form>
<!-- End SearchForm -->